# CS229 Materials (Autumn 2017)

Materials from Stanford's CS229 Autumn 2017 course.
